package com.shangzf.email.service.impl;

import com.shangzf.email.service.IEmailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * @author shangzf
 */
@Slf4j
@Service
public class EmailServiceImpl implements IEmailService {

    @Value("${spring.mail.username}")
    private String sender;

    private final JavaMailSender mailSender;

    public EmailServiceImpl(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Async("taskExecutor")
    @Override
    public void send(String email, String code) {
        try {
            log.info("发送邮件：{},验证码：{}", email, code);
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(sender);
            message.setTo(email);
            message.setSubject("验证码");
            message.setText("尊敬的用户,您好:\n"
                    + "\n本次请求的邮件验证码为:" + code + ",本验证码5分钟内有效，请及时输入。（请勿泄露此验证码）\n"
                    + "\n如非本人操作，请忽略该邮件。\n(这是一封自动发送的邮件，请不要直接回复）");    //设置邮件正文
            mailSender.send(message);
        } catch (MailException e) {
            e.printStackTrace();
            log.error("{}发送失败,原因：{}", email, e.getMessage());
        }
    }
}
