package com.shangzf.email.controller;

import com.shangzf.email.service.IEmailService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author shangzf
 */
@RestController
public class EmailController {
    private final IEmailService emailService;

    public EmailController(IEmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping(value = "/email/{email}/{code}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean email(@PathVariable String email,
                         @PathVariable String code) {
        emailService.send(email, code);
        return Boolean.TRUE;
    }
}
