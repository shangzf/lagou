package com.shangzf.user.controller;

import com.shangzf.user.service.ITokenService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author shangzf
 */
@RestController
@RequestMapping("/user")
public class TokenController {

    private final ITokenService tokenService;

    public TokenController(ITokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * 根据token查询⽤户登录邮箱接⼝
     *
     * @param token 令牌
     * @return 邮箱地址
     */
    @GetMapping(value = "/info/{token}", produces = MediaType.APPLICATION_JSON_VALUE)
    public String info(@PathVariable String token) {
        return tokenService.info(token);
    }
}
