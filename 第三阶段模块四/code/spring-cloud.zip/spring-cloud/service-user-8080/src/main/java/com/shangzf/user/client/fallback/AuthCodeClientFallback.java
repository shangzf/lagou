package com.shangzf.user.client.fallback;

import com.shangzf.user.client.AuthCodeClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author shangzf
 */
@Slf4j
@Component
public class AuthCodeClientFallback implements AuthCodeClient {
    @Override
    public Integer validate(String email, String code) {
        log.error("请求失败,方法：{},{}-{}", "validate", email, code);
        return 2;
    }
}
