package com.shangzf.user.client;

import com.shangzf.user.client.fallback.AuthCodeClientFallback;
import com.shangzf.user.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author shangzf
 */
@FeignClient(value = "service-code"
        , path = "/code"
        , fallback = AuthCodeClientFallback.class
        , configuration = FeignClientConfig.class)
public interface AuthCodeClient {

    @GetMapping(value = "/validate/{email}/{code}")
    Integer validate(@PathVariable("email") String email,
                     @PathVariable("code") String code);
}
