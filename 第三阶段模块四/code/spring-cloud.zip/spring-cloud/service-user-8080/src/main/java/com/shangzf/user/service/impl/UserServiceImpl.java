package com.shangzf.user.service.impl;

import com.shangzf.user.client.AuthCodeClient;
import com.shangzf.user.dao.TokenDao;
import com.shangzf.user.dao.UserDao;
import com.shangzf.user.pojo.Token;
import com.shangzf.user.pojo.User;
import com.shangzf.user.service.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

/**
 * @author shangzf
 */
@Slf4j
@Service
public class UserServiceImpl implements IUserService {

    private final UserDao userDao;
    private final TokenDao tokenDao;

    private final AuthCodeClient codeClient;

    public UserServiceImpl(UserDao userDao, TokenDao tokenDao, AuthCodeClient codeClient) {
        this.userDao = userDao;
        this.tokenDao = tokenDao;
        this.codeClient = codeClient;
    }

    @Override
    public Boolean register(String email, String password, String code) {
        // 校验验证码是否正确
        Integer validate = codeClient.validate(email, code);
        if (validate == 2) {
            log.error("请求超时");
            return Boolean.FALSE;
        }
        if (validate == 1) {
            log.info("验证码错误");
            return Boolean.FALSE;
        }
        // 保存
        User user = User.builder()
                .email(email)
                .password(password)
                .createTime(new Date())
                .build();
        userDao.save(user);
        return Boolean.TRUE;
    }

    @Override
    public Boolean isRegistered(String email) {
        // 查询条件
        log.info("验证是否注册：{}", email);
        Example<User> example = Example.of(User.builder().email(email).build());
        return userDao.exists(example);
    }

    @Override
    public String login(String email, String password) {
        // 登录
        log.info("登录：{}", email);
        boolean exists = userDao.exists(Example.of(User.builder().email(email).password(password).build()));
        if (!exists) {
            log.error("用户名或密码错误！");
            throw new RuntimeException("用户名或密码错误！");
        }
        // 生成token
        String token = UUID.randomUUID().toString();
        // 保存token
        tokenDao.save(Token.builder().email(email).token(token).build());
        return token;
    }
}
