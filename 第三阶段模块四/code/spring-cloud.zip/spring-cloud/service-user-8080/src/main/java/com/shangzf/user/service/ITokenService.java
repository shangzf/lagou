package com.shangzf.user.service;

/**
 * @author shangzf
 */
public interface ITokenService {
    String info(String token);
}
