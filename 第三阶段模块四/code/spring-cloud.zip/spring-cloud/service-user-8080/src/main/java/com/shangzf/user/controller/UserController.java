package com.shangzf.user.controller;

import com.shangzf.user.service.IUserService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author shangzf
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private final IUserService userService;

    public UserController(IUserService userService) {
        this.userService = userService;
    }

    /**
     * 注册接⼝
     *
     * @param email    邮箱
     * @param password 密码
     * @param code     验证码
     * @return 注册状态：true成功，false失败
     */
    @PostMapping(value = "/register/{email}/{password}/{code}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean register(@PathVariable String email,
                            @PathVariable String password,
                            @PathVariable String code) {
        return userService.register(email, password, code);
    }

    /**
     * 是否已注册，根据邮箱判断
     *
     * @param email 邮箱
     * @return true代表已经注册过， false代表尚未注册
     */
    @GetMapping(value = "/isRegistered/{email}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean isRegistered(@PathVariable String email) {
        return userService.isRegistered(email);
    }

    /**
     * 登录接⼝，验证⽤户名密码合法性，
     * 根据⽤户名和密码⽣成token，token存⼊数据库，
     * 并写⼊cookie中，登录成功返回邮箱地址，重定向到欢迎⻚页
     *
     * @param email    ⽤户名
     * @param password 密码
     * @return 邮箱地址
     */
    @PostMapping(value = "/login/{email}/{password}", produces = MediaType.APPLICATION_JSON_VALUE)
    public String login(@PathVariable String email,
                        @PathVariable String password,
                        HttpServletRequest request,
                        HttpServletResponse response) {
        String token = userService.login(email, password);
        setCookie(token, request, response);
        return email;
    }

    private void setCookie(String token, HttpServletRequest request, HttpServletResponse response) {
        Cookie tokenCookie = new Cookie("token", token);
        tokenCookie.setPath("/");
        response.addCookie(tokenCookie);
    }

}
