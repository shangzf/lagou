package com.shangzf.client.fallback;

import com.shangzf.client.UserClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author shangzf
 */
@Slf4j
@Component
public class UserClientFallback implements UserClient {
    @Override
    public String info(String token) {
        log.error("请求失败,方法：{},{}", "info", token);
        return "";
    }
}
