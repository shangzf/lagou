package com.shangzf.filter;

import com.shangzf.client.UserClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * @author shangzf
 */
@Slf4j

@Component
public class TokenFilter implements GlobalFilter, Ordered {

    @Value("${token.limit-path}")
    private String tokenLimitPath;

    @Autowired
    private UserClient userClient;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();
        if (StringUtils.isNotBlank(tokenLimitPath)) {
            String path = request.getURI().getPath();
            String[] split = tokenLimitPath.split(",");
            for (String s : split) {
                if (path.contains(s)) {
                    return chain.filter(exchange);
                }
            }
        }
        return checkToken(exchange, chain, request, response);
    }

    private Mono<Void> checkToken(ServerWebExchange exchange, GatewayFilterChain chain, ServerHttpRequest request, ServerHttpResponse response) {
        HttpCookie token = request.getCookies().getFirst("token");
        if (Objects.isNull(token)) {
            return getDenied(response);
        }
        // 请求下游服务器
        String info = userClient.info(token.getValue());
        if (StringUtils.isBlank(info)) {
            return getDenied(response);
        }
        return chain.filter(exchange);
    }

    private Mono<Void> getDenied(ServerHttpResponse response) {
        // 状态码
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        HttpHeaders headers = response.getHeaders();
        log.debug("未经授权,请求被拒绝访问！");
        String data = "Unauthorized, request denied access!";
        DataBuffer wrap = response.bufferFactory().wrap(data.getBytes(StandardCharsets.UTF_8));
        return response.writeWith(Mono.just(wrap));
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
