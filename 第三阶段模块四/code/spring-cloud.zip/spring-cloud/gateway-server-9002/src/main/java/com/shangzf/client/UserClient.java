package com.shangzf.client;

import com.shangzf.client.fallback.UserClientFallback;
import com.shangzf.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author shangzf
 */
@FeignClient(value = "service-user"
        , path = "/user"
        , fallback = UserClientFallback.class
        , configuration = FeignClientConfig.class)
public interface UserClient {

    @GetMapping(value = "/info/{token}")
    String info(@PathVariable("token") String token);
}
