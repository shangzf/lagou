package com.shangzf.code.client.fallback;

import com.shangzf.code.client.EmailClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author shangzf
 */
@Slf4j
@Component
public class EmailClientFallback implements EmailClient {
    @Override
    public Boolean email(String email, String code) {
        log.error("请求失败,方法：{},{}-{}", "email", email, code);
        return Boolean.FALSE;
    }
}
