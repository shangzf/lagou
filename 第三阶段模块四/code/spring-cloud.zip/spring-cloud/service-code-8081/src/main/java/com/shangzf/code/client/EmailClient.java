package com.shangzf.code.client;

import com.shangzf.code.client.fallback.EmailClientFallback;
import com.shangzf.code.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author shangzf
 */
@FeignClient(value = "SERVICE-EMAIL"
        , fallback = EmailClientFallback.class
        , configuration = FeignClientConfig.class)
public interface EmailClient {

    @PostMapping(value = "/email/{email}/{code}")
    Boolean email(@PathVariable("email") String email, @PathVariable("code") String code);
}
