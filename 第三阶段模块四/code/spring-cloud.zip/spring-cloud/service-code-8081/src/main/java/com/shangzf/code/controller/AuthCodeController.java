package com.shangzf.code.controller;

import com.shangzf.code.service.IAuthCodeService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author shangzf
 */
@RestController
@RequestMapping("/code")
public class AuthCodeController {

    private final IAuthCodeService codeService;

    public AuthCodeController(IAuthCodeService codeService) {
        this.codeService = codeService;
    }

    /**
     * 校验验证码是否正确，
     *
     * @param email 邮箱
     * @param code  验证码
     * @return 0正确1错误2超时
     */
    @GetMapping(value = "/validate/{email}/{code}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Integer validate(@PathVariable String email,
                            @PathVariable String code) {
        return codeService.validate(email, code);
    }

    /**
     * ⽣成验证码并发送到对应邮箱，
     *
     * @param email 邮箱
     * @return 成功true，失败 false
     */
    @PostMapping(value = "/create/{email}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean create(@PathVariable String email) {
        return codeService.create(email);
    }
}
