package com.shangzf.code.service;

/**
 * @author shangzf
 */
public interface IAuthCodeService {
    Integer validate(String email, String code);

    Boolean create(String email);
}
