package com.shangzf.api.code;

/**
 * @author shangzf
 */
public interface IAuthCodeService {

    Integer validate(String email, String code);

    String create(String email);
}
