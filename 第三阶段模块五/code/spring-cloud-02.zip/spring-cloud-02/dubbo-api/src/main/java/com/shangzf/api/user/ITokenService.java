package com.shangzf.api.user;

/**
 * @author shangzf
 */
public interface ITokenService {
    String info(String token);
}
