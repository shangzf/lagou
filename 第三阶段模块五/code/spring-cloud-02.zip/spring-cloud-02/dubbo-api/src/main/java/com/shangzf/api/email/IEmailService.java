package com.shangzf.api.email;

/**
 * @author shangzf
 */
public interface IEmailService {
    void send(String email, String code);
}
