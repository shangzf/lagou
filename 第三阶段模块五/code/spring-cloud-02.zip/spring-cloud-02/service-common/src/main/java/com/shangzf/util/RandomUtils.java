package com.shangzf.util;

import java.util.Random;

/**
 * @author shangzf
 */
public final class RandomUtils {

    public static String randomCode(){
        final String[] str = {"0","1","2","3","4","5","6","7","8","9"};
        StringBuilder buffer = new StringBuilder("");
        for (int i = 0; i < 6; i++) {
            int index = new Random().nextInt(str.length);
            buffer.append(str[index]);
        }
        return buffer.toString();
    }
}
