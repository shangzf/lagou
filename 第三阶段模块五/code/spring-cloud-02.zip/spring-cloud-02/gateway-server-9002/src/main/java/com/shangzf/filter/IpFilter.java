package com.shangzf.filter;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * IP防止爆刷
 *
 * @author shangzf
 */
@Slf4j
@Component
public class IpFilter implements GlobalFilter, Ordered {

    private final Map<String, List<RequestIp>> IpLimitMap = new ConcurrentHashMap<>();

    private final List<String> whiteList = new ArrayList<>();

    /**
     * 限制分钟
     */
    @Value("${ip.limit-minutes}")
    private Long ipLimitMinutes;
    /**
     * 限制次数
     */
    @Value("${ip.limit-times}")
    private Long ipLimitTimes;

    /**
     * 限制的请求
     */
    @Value("${ip.limit-path}")
    private String ipLimitPath;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();
        // 获取请求地址
        String path = request.getURI().getPath();
        if (StringUtils.isNotBlank(ipLimitPath)) {
            String[] split = ipLimitPath.split(",");
            for (String s : split) {
                if (path.contains(s)) {
                    return ipLimit(exchange, chain, request, response);
                }
            }
            return chain.filter(exchange);
        }
        return ipLimit(exchange, chain, request, response);
    }

    private Mono<Void> ipLimit(ServerWebExchange exchange, GatewayFilterChain chain, ServerHttpRequest request, ServerHttpResponse response) {
        // 获取请求IP，对请求的IP进行判断
        String clientIp = Objects.requireNonNull(request.getRemoteAddress()).getHostString();
        // 获取请求列表
        List<RequestIp> requestIpList = IpLimitMap.get(clientIp);
        // 如果请求列表中不存在，则存放集合中，并放行
        if (Objects.isNull(requestIpList)) {
            return chain.filter(exchange);
        }
        // 查询列表，获取在限制分钟内的请求个数
        long count = requestIpList.stream().filter(requestIp -> System.currentTimeMillis() - requestIp.requestTime < ipLimitMinutes * 60 * 100).count();
        if (count < ipLimitTimes) {
            return chain.filter(exchange);
        }
        // 状态码
        response.setStatusCode(HttpStatus.SEE_OTHER);
        log.debug("=====>IP:" + clientIp + " 进行注册，请求已被拒绝！");
        String data = "You register frequently and your request has been rejected!";
        DataBuffer wrap = response.bufferFactory().wrap(data.getBytes(StandardCharsets.UTF_8));
        return response.writeWith(Mono.just(wrap));
    }

    @Override
    public int getOrder() {
        return 0;
    }

    private static class RequestIp {
        private Long requestTime;

        public Long getRequestTime() {
            return requestTime;
        }

        public void setRequestTime(Long requestTime) {
            this.requestTime = requestTime;
        }
    }
}
