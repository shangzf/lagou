package com.shangzf.user.dao;

import com.shangzf.user.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shangzf
 */
public interface UserDao extends JpaRepository<User, Long> {
}
