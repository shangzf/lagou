package com.shangzf.user.service.impl;

import com.shangzf.api.user.ITokenService;
import com.shangzf.user.dao.TokenDao;
import com.shangzf.user.pojo.Token;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.data.domain.Example;

/**
 * @author shangzf
 */
@Slf4j
@Service
public class TokenServiceImpl implements ITokenService {

    private final TokenDao tokenDao;

    public TokenServiceImpl(TokenDao tokenDao) {
        this.tokenDao = tokenDao;
    }

    @Override
    public String info(String token) {
        return tokenDao.findOne(Example.of(Token.builder().token(token).build())).orElseThrow(() -> {
            log.error("token异常");
            throw new RuntimeException("token异常");
        }).getEmail();
    }
}
