package com.shangzf.user.dao;

import com.shangzf.user.pojo.Token;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shangzf
 */
public interface TokenDao extends JpaRepository<Token, Long> {
}
