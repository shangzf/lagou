package com.shangzf.user.service;

/**
 * @author shangzf
 */
public interface IUserService {
    Boolean register(String email, String password, Integer validate);

    Boolean isRegistered(String email);

    String login(String email, String password);
}
