package com.shangzf.code.service.impl;

import com.shangzf.api.code.IAuthCodeService;
import com.shangzf.code.dao.AuthCodeDao;
import com.shangzf.code.pojo.AuthCode;
import com.shangzf.util.RandomUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;

import java.util.Date;
import java.util.Objects;

/**
 * @author shangzf
 */
@Slf4j
@Service
public class AuthCodeServiceImpl implements IAuthCodeService {

    @Autowired
    private AuthCodeDao authCodeDao;

    @Override
    public Integer validate(String email, String code) {
        AuthCode authCode =
                authCodeDao.findOne(Example.of(AuthCode.builder().code(code).email(email).build())).orElseGet(AuthCode::new);
        // 验证时间
        return checkTime(authCode.getExpireTime());
    }

    private Integer checkTime(Date expireTime) {
        if (Objects.isNull(expireTime)) {
            log.error("验证码错误");
            return 1;
        }
        boolean check = new Date().before(expireTime);
        return check ? 0 : 2;
    }

    @Override
    public String create(String email) {
        // 获取验证码
        String code = RandomUtils.randomCode();
        // 存放数据库
        long expire = System.currentTimeMillis() + (10 * 60 * 1000);
        authCodeDao.save(AuthCode.builder().code(code).email(email).createTime(new Date()).expireTime(new Date(expire)).build());
        return code;
    }

}
