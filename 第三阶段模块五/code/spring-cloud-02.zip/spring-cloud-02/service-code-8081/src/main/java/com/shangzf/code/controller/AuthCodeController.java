package com.shangzf.code.controller;

import com.shangzf.api.code.IAuthCodeService;
import com.shangzf.api.email.IEmailService;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * @author shangzf
 */
@RestController
@RequestMapping("/code")
public class AuthCodeController {

    @Reference
    private IAuthCodeService codeService;

    @Reference
    private IEmailService emailService;

    /**
     * ⽣成验证码并发送到对应邮箱，
     *
     * @param email 邮箱
     * @return 成功true，失败 false
     */
    @PostMapping(value = "/create/{email}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean create(@PathVariable String email) {
        String code = codeService.create(email);
        emailService.send(email, code);
        return Boolean.TRUE;
    }
}
