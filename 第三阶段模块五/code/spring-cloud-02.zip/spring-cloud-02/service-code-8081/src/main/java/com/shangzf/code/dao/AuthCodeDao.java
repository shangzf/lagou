package com.shangzf.code.dao;

import com.shangzf.code.pojo.AuthCode;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author shangzf
 */
public interface AuthCodeDao extends JpaRepository<AuthCode, Long> {
}
